<?php
define ('THEME_LANG','theme_language');


// Add Kien Bien Library Functionrequire_once TEMPLATEPATH . '/core/shortcode.php';
require_once TEMPLATEPATH . '/core/theme-setup.php';
require_once TEMPLATEPATH . '/core/theme-setting.php';
require_once TEMPLATEPATH . '/core/theme-functions.php';
require_once TEMPLATEPATH . '/core/navigations.php';
require_once TEMPLATEPATH . '/core/widgets.php';
require_once TEMPLATEPATH . '/core/shortcode.php';
require_once TEMPLATEPATH . '/core/theme-styless.php';
require_once TEMPLATEPATH . '/core/ajax.php';
require_once TEMPLATEPATH . '/core/custom-widgets.php';

