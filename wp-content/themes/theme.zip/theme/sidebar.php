<?php
/**
 * The Sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>
 <aside id="sidebar" class="">
    <div class="box-sidebar">
       <?php dynamic_sidebar('ads-left')?>
    </div>
   
    <div class="box-sidebar">
       
    </div>    

    <div class="box-sidebar">
      
    </div>    
</aside>
